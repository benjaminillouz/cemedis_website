# Site Web CEMEDIS

Site vitrine du réseau de soins dentaires et médicaux CEMEDIS.

## 🏥 À propos

CEMEDIS est un réseau de 26 établissements à Paris et en Île-de-France, offrant des soins dentaires et médicaux de qualité avec une prise en charge globale et pluridisciplinaire.

## ✨ Fonctionnalités

- ✅ **Site responsive** - Optimisé pour mobile, tablette et desktop
- ✅ **Intégration Supabase** - Chargement dynamique des centres depuis la base de données
- ✅ **Pages principales** :
  - Accueil avec statistiques dynamiques
  - Liste des établissements avec filtres
  - Consultations et services
  - Urgences dentaires
  - Nous rejoindre (recrutement)
  - Contact
- ✅ **Déploiement Firebase** - Hosting sur Firebase avec déploiement automatique

## 🚀 Technologies

- **HTML5** / **CSS3** / **JavaScript**
- **Tailwind CSS** - Framework CSS utilitaire
- **Supabase** - Backend as a Service pour les données
- **Firebase Hosting** - Hébergement et déploiement

## 📋 Prérequis

- Node.js et npm (pour les scripts de déploiement)
- Firebase CLI : `npm install -g firebase-tools`
- Compte Supabase avec accès à la table `centres`

## 🔧 Configuration

### 1. Configuration Supabase

1. Copiez `js/supabase-config.example.js` en `js/supabase-config.js`
2. Remplissez vos clés Supabase dans `js/supabase-config.js`
3. Voir [README-SUPABASE.md](README-SUPABASE.md) pour plus de détails

### 2. Configuration Firebase

Le projet est déjà configuré pour :
- **Projet Firebase** : `pecapi-app`
- **Site de hosting** : `cemedis`

Voir [README-DEPLOY.md](README-DEPLOY.md) pour le déploiement.

## 📦 Installation

```bash
# Cloner le dépôt
git clone https://github.com/vAugagneur/cemedis-website.git
cd cemedis-website

# Installer les dépendances (optionnel)
npm install
```

## 🚀 Déploiement

### Déploiement manuel

```bash
# Déployer sur Firebase
./deploy.sh

# Ou avec npm
npm run deploy
```

### Déploiement automatique

Le site se déploie automatiquement sur Firebase via GitHub Actions à chaque push sur la branche `main`.

## 📁 Structure du projet

```
cemedis-website/
├── index.html              # Page d'accueil
├── etablissements.html     # Liste des établissements
├── consultations.html      # Services et consultations
├── urgences.html          # Centres d'urgences
├── rejoindre.html         # Recrutement
├── contact.html           # Contact
├── js/
│   ├── main.js            # JavaScript principal
│   ├── centres-service.js  # Service Supabase pour les centres
│   ├── etablissements.js   # Logique page établissements
│   ├── supabase-config.js  # Configuration Supabase
│   └── supabase-config.example.js
├── firebase.json           # Configuration Firebase
├── .firebaserc            # Projets Firebase
├── deploy.sh              # Script de déploiement
└── README*.md            # Documentation
```

## 🌐 URLs

- **Site en production** : https://cemedis.web.app
- **Dépôt GitHub** : https://github.com/vAugagneur/cemedis-website

## 📝 Documentation

- [README-SUPABASE.md](README-SUPABASE.md) - Configuration Supabase
- [README-DEPLOY.md](README-DEPLOY.md) - Guide de déploiement Firebase

## 🤝 Contribution

Les contributions sont les bienvenues ! N'hésitez pas à ouvrir une issue ou une pull request.

## 📄 Licence

Propriétaire - CEMEDIS © 2024

## 👥 Équipe

Développé pour CEMEDIS - Réseau de soins dentaires et médicaux
