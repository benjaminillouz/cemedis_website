# Configuration Supabase

## 🚀 Étapes pour configurer Supabase

### 1. Obtenir vos clés Supabase

1. Allez sur https://supabase.com
2. Connectez-vous à votre compte
3. Sélectionnez votre projet CEMEDIS
4. Allez dans **Settings** > **API**
5. Copiez :
   - **Project URL** (ex: `https://abcdefghijklmnop.supabase.co`)
   - **anon public** key (la clé publique anonyme)

### 2. Configurer les clés dans le projet

1. Ouvrez le fichier `js/supabase-config.js`
2. Remplacez les valeurs :
   ```javascript
   const SUPABASE_CONFIG = {
       url: 'https://VOTRE-PROJECT-ID.supabase.co',  // ← Votre URL
       anonKey: 'VOTRE-CLE-ANON-ICI'                 // ← Votre clé anonyme
   };
   ```

### 3. Vérifier les permissions de la table

La table `centres` doit être accessible en lecture publique. Exécutez ces commandes SQL dans l'éditeur SQL de Supabase :

```sql
-- Activer RLS (Row Level Security)
ALTER TABLE centres ENABLE ROW LEVEL SECURITY;

-- Créer une politique pour permettre la lecture publique des centres actifs
CREATE POLICY "Allow public read access to active centres" 
ON centres
FOR SELECT 
USING (statut = 'actif');
```

### 4. Structure de la table utilisée

Le code utilise les colonnes suivantes de la table `centres` :
- `id` (uuid) - Identifiant unique
- `nom` (varchar) - Nom du centre
- `adresse` (text) - Adresse complète
- `code_postal` (varchar) - Code postal
- `ville` (varchar) - Ville
- `telephone` (varchar) - Numéro de téléphone
- `email` (varchar) - Email du centre
- `horaires_ouverture` (jsonb) - Horaires au format JSON
- `statut` (varchar) - Statut du centre (doit être 'actif' pour être affiché)
- `latitude` (double) - Latitude pour la géolocalisation
- `longitude` (double) - Longitude pour la géolocalisation

### 5. Tester la connexion

1. Ouvrez `index.html` dans votre navigateur
2. Ouvrez la console du navigateur (F12)
3. Vérifiez qu'il n'y a pas d'erreurs de connexion
4. Les statistiques doivent se charger automatiquement

## 📝 Pages mises à jour

Toutes les pages suivantes chargent maintenant les centres depuis Supabase :

- ✅ **index.html** - Statistiques dynamiques (nombre de centres, urgences)
- ✅ **etablissements.html** - Liste complète des centres avec filtres
- ✅ **urgences.html** - Centres d'urgences dynamiques
- ✅ **contact.html** - Liste des centres dans le formulaire

## 🔧 Dépannage

### Erreur : "Supabase client not initialized"
- Vérifiez que la bibliothèque Supabase est chargée avant `supabase-config.js`
- Vérifiez que vos clés sont correctes

### Erreur : "Error loading centres"
- Vérifiez les permissions RLS de la table `centres`
- Vérifiez que la table contient des centres avec `statut = 'actif'`
- Vérifiez la console du navigateur pour plus de détails

### Les centres ne s'affichent pas
- Vérifiez que la table `centres` contient des données
- Vérifiez que les centres ont `statut = 'actif'`
- Vérifiez les permissions RLS

## 📦 Fichiers créés

- `js/supabase-config.js` - Configuration Supabase (à remplir avec vos clés)
- `js/supabase-config.example.js` - Exemple de configuration
- `js/centres-service.js` - Service pour gérer les centres depuis Supabase
- `js/etablissements.js` - Mise à jour pour charger depuis Supabase