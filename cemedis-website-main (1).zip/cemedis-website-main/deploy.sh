#!/bin/bash

# Script de déploiement Firebase pour CEMEDIS
# Déploie le site sur le projet pecapi-app, site de hosting "cemedis"

set -e  # Arrêter en cas d'erreur

echo "🚀 Déploiement du site CEMEDIS sur Firebase..."
echo ""

# Vérifier que Firebase CLI est installé
if ! command -v firebase &> /dev/null; then
    echo "❌ Firebase CLI n'est pas installé."
    echo "   Installez-le avec: npm install -g firebase-tools"
    exit 1
fi

# Vérifier que l'utilisateur est connecté
if ! firebase projects:list &> /dev/null; then
    echo "❌ Vous n'êtes pas connecté à Firebase."
    echo "   Connectez-vous avec: firebase login"
    exit 1
fi

# Utiliser le projet pecapi-app
echo "📦 Configuration du projet pecapi-app..."
firebase use pecapi-app

# Déployer sur le site de hosting "cemedis"
echo "📦 Déploiement sur le site cemedis..."
if firebase deploy --only hosting; then
    echo "✅ Déploiement réussi !"
    echo ""
    echo "📋 URL du site:"
    echo "   https://cemedis.web.app"
    echo "   ou"
    echo "   https://cemedis.firebaseapp.com"
else
    echo "❌ Erreur lors du déploiement"
    exit 1
fi

echo ""
echo "🎉 Déploiement terminé avec succès !"
