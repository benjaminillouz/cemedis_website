# Configuration GitHub Actions

Ce guide explique comment configurer le déploiement automatique sur Firebase via GitHub Actions.

## 🔑 Configuration du secret Firebase

Pour activer le déploiement automatique, vous devez ajouter un token Firebase dans les secrets GitHub.

### 1. Générer un token Firebase

```bash
firebase login:ci
```

Cette commande affichera un token. **Copiez ce token**, vous en aurez besoin à l'étape suivante.

### 2. Ajouter le secret dans GitHub

1. Allez sur https://github.com/vAugagneur/cemedis-website
2. Cliquez sur **Settings** (Paramètres)
3. Dans le menu de gauche, cliquez sur **Secrets and variables** > **Actions**
4. Cliquez sur **New repository secret**
5. Nom : `FIREBASE_TOKEN`
6. Valeur : Collez le token généré à l'étape 1
7. Cliquez sur **Add secret**

### 3. Vérifier le workflow

Une fois le secret configuré, le workflow se déclenchera automatiquement à chaque push sur la branche `main`.

Vous pouvez voir l'état des déploiements dans l'onglet **Actions** du dépôt GitHub.

## 🔄 Déploiement manuel

Si vous préférez déployer manuellement, vous pouvez aussi déclencher le workflow manuellement :

1. Allez dans l'onglet **Actions**
2. Sélectionnez le workflow **Deploy to Firebase**
3. Cliquez sur **Run workflow**
4. Sélectionnez la branche `main`
5. Cliquez sur **Run workflow**

## 📝 Notes

- Le workflow déploie uniquement sur le projet `pecapi-app` avec le site `cemedis`
- Le déploiement se fait uniquement depuis la branche `main`
- Les erreurs de déploiement seront visibles dans l'onglet Actions
