# Guide de déploiement Firebase

Ce guide explique comment déployer le site CEMEDIS sur Firebase Hosting.

## 📋 Prérequis

1. **Node.js et npm** installés
2. **Firebase CLI** installé globalement :
   ```bash
   npm install -g firebase-tools
   ```
3. **Compte Firebase** avec accès au projet `pecapi-app`

## 🚀 Configuration initiale

### 1. Se connecter à Firebase

```bash
firebase login
```

### 2. Initialiser Firebase (si pas déjà fait)

```bash
firebase init hosting
```

Sélectionnez :
- ✅ Firebase Hosting
- Utiliser un projet existant
- Choisir `pecapi-app`
- Nom du site de hosting : `cemedis`

## 📦 Déploiement

### Déploiement simple

```bash
# Utiliser le projet pecapi-app
firebase use pecapi-app

# Déployer sur le site "cemedis"
firebase deploy --only hosting
```

### Déploiement avec le script

```bash
./deploy.sh
```

### Déploiement avec npm

```bash
npm run deploy
```

## 🔧 Scripts de déploiement rapide

### Option 1 : Script shell

Créez un fichier `deploy.sh` :

```bash
#!/bin/bash

echo "🚀 Déploiement sur pecapi-app..."
firebase use pecapi-app
firebase deploy --only hosting

echo "🚀 Déploiement sur cemedis..."
firebase use cemedis
firebase deploy --only hosting

echo "✅ Déploiement terminé !"
```

Rendez-le exécutable :
```bash
chmod +x deploy.sh
./deploy.sh
```

### Option 2 : Script npm

```bash
npm run deploy
```

## 🌐 URL de déploiement

Après le déploiement, le site sera accessible sur :

- **cemedis** : `https://cemedis.web.app` ou `https://cemedis.firebaseapp.com`

Vous pouvez aussi configurer un domaine personnalisé dans la console Firebase.

## ⚙️ Configuration Firebase

### Fichiers de configuration

- **`.firebaserc`** : Configuration des projets Firebase
- **`firebase.json`** : Configuration du hosting (répertoire public, rewrites, headers)
- **`.firebaseignore`** : Fichiers à exclure du déploiement

### Personnaliser la configuration

Modifiez `firebase.json` pour :
- Changer le répertoire public
- Ajouter des rewrites personnalisés
- Configurer les headers de cache
- Ajouter des redirects

## 🔍 Vérification avant déploiement

1. **Vérifier la configuration Supabase** :
   - Assurez-vous que `js/supabase-config.js` contient les bonnes clés
   - Testez localement que les centres se chargent correctement

2. **Tester localement** :
   ```bash
   firebase serve
   ```
   Puis ouvrez http://localhost:5000

3. **Vérifier les fichiers** :
   - Tous les fichiers HTML sont présents
   - Les fichiers JS sont correctement référencés
   - Les chemins sont relatifs (pas de chemins absolus)

## 🐛 Dépannage

### Erreur : "Firebase project not found"
- Vérifiez que vous êtes connecté : `firebase login`
- Vérifiez que vous avez accès aux projets dans la console Firebase
- Vérifiez le fichier `.firebaserc`

### Erreur : "Permission denied"
- Vérifiez vos permissions sur les projets Firebase
- Contactez l'administrateur du projet

### Le site ne se charge pas après déploiement
- Vérifiez les logs : `firebase hosting:channel:list`
- Vérifiez la console Firebase pour les erreurs
- Testez en local avec `firebase serve`

## 📝 Commandes utiles

```bash
# Voir les projets disponibles
firebase projects:list

# Voir le projet actuel
firebase use

# Lister les sites de hosting
firebase hosting:sites:list

# Voir l'historique des déploiements
firebase hosting:clone

# Ouvrir la console Firebase
firebase open
```

## 🔄 Déploiement continu (CI/CD)

Pour automatiser le déploiement, vous pouvez utiliser GitHub Actions :

```yaml
# .github/workflows/deploy.yml
name: Deploy to Firebase

on:
  push:
    branches: [ main ]

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      - uses: actions/setup-node@v2
      - run: npm install -g firebase-tools
      - run: firebase use pecapi-app --token ${{ secrets.FIREBASE_TOKEN }}
      - run: firebase deploy --only hosting --token ${{ secrets.FIREBASE_TOKEN }}
```

## 📚 Ressources

- [Documentation Firebase Hosting](https://firebase.google.com/docs/hosting)
- [Firebase CLI Reference](https://firebase.google.com/docs/cli)
- [Console Firebase](https://console.firebase.google.com/)
