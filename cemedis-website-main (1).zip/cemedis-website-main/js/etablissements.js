// Establishments page specific JavaScript - Chargement depuis Supabase

let allCentres = [];
let displayedCentres = [];
const centresPerPage = 9;
let currentPage = 1;

// Fonction pour charger les centres depuis Supabase
async function loadCentres() {
    const loadingState = document.getElementById('loading-state');
    const errorState = document.getElementById('error-state');
    const grid = document.getElementById('establishments-grid');
    
    try {
        // Afficher l'état de chargement
        if (loadingState) loadingState.classList.remove('hidden');
        if (errorState) errorState.classList.add('hidden');
        if (grid) grid.classList.add('hidden');
        
        // Charger les centres depuis Supabase
        await centresService.loadCentres();
        allCentres = centresService.getCentres();
        
        if (allCentres.length === 0) {
            throw new Error('Aucun centre trouvé');
        }
        
        // Cacher le chargement et afficher la grille
        if (loadingState) loadingState.classList.add('hidden');
        if (grid) grid.classList.remove('hidden');
        
        // Afficher les centres
        displayCentres();
        
        // Mettre à jour les filtres d'arrondissement
        updateArrondissementFilter();
        
    } catch (error) {
        console.error('Error loading centres:', error);
        if (loadingState) loadingState.classList.add('hidden');
        if (errorState) errorState.classList.remove('hidden');
        if (grid) grid.classList.add('hidden');
    }
}

// Fonction pour afficher les centres
function displayCentres(filteredCentres = null) {
    const grid = document.getElementById('establishments-grid');
    if (!grid) return;
    
    const centresToDisplay = filteredCentres || allCentres;
    displayedCentres = centresToDisplay;
    
    // Réinitialiser la pagination
    currentPage = 1;
    
    // Afficher les premiers centres
    renderCentres(centresToDisplay.slice(0, centresPerPage));
    
    // Afficher le bouton "Voir plus" si nécessaire
    const loadMoreContainer = document.getElementById('load-more-container');
    const loadMoreButton = document.getElementById('load-more');
    const centresCount = document.getElementById('centres-count');
    
    if (centresToDisplay.length > centresPerPage) {
        if (loadMoreContainer) loadMoreContainer.classList.remove('hidden');
        if (loadMoreButton) {
            loadMoreButton.disabled = false;
            loadMoreButton.classList.remove('bg-gray-400', 'cursor-not-allowed');
            loadMoreButton.classList.add('bg-cemedis-blue', 'hover:bg-cemedis-light-blue');
        }
    } else {
        if (loadMoreContainer) loadMoreContainer.classList.add('hidden');
    }
    
    // Mettre à jour le compteur
    if (centresCount) {
        const displayed = Math.min(centresPerPage, centresToDisplay.length);
        centresCount.textContent = `Affichage de ${displayed} sur ${centresToDisplay.length} établissements`;
    }
}

// Fonction pour rendre les cartes de centres
function renderCentres(centres) {
    const grid = document.getElementById('establishments-grid');
    if (!grid) return;
    
    // Si on charge plus de centres, les ajouter, sinon remplacer
    if (currentPage === 1) {
        grid.innerHTML = '';
    }
    
    centres.forEach(centre => {
        const card = createCentreCard(centre);
        grid.appendChild(card);
    });
}

// Fonction pour créer une carte de centre
function createCentreCard(centre) {
    const isUrgence = centresService.isUrgenceCentre(centre);
    const arrondissement = centresService.getArrondissement(centre.code_postal);
    const adresseComplete = centresService.formatAdresse(centre);
    const horaires = centresService.formatHoraires(centre.horaires_ouverture);
    
    const card = document.createElement('div');
    card.className = `establishment-card bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-all duration-300 ${isUrgence ? 'border-2 border-red-200' : ''}`;
    card.dataset.id = centre.id;
    card.dataset.city = centre.ville?.toLowerCase() || '';
    card.dataset.arrondissement = centre.code_postal || '';
    
    const headerColor = isUrgence ? 'bg-red-600' : 'bg-cemedis-blue';
    const headerTextColor = isUrgence ? 'text-red-100' : 'text-blue-100';
    const iconColor = isUrgence ? 'text-red-600' : 'text-cemedis-blue';
    const buttonColor = isUrgence ? 'bg-red-600 hover:bg-red-700' : 'bg-cemedis-blue hover:bg-cemedis-light-blue';
    const borderColor = isUrgence ? 'border-red-600' : 'border-cemedis-blue';
    
    const locationText = arrondissement || centre.ville || '';
    const locationSubtext = isUrgence ? ' - Centre d\'urgences' : '';
    
    card.innerHTML = `
        <div class="${headerColor} text-white p-4">
            <h3 class="text-xl font-bold">${centre.nom || 'Centre CEMEDIS'}</h3>
            <p class="${headerTextColor}">${locationText}${locationSubtext}</p>
        </div>
        <div class="p-6">
            <div class="space-y-3 mb-4">
                <div class="flex items-center text-gray-600">
                    <i class="fas fa-map-marker-alt w-5 ${iconColor}"></i>
                    <span class="ml-2">${adresseComplete}</span>
                </div>
                ${centre.telephone ? `
                <div class="flex items-center text-gray-600">
                    <i class="fas fa-phone w-5 ${iconColor}"></i>
                    <span class="ml-2">${centre.telephone}</span>
                </div>
                ` : ''}
                <div class="flex items-center text-gray-600">
                    <i class="fas fa-clock w-5 ${iconColor}"></i>
                    <span class="ml-2">${horaires}</span>
                </div>
            </div>
            
            <div class="mb-4">
                <h4 class="font-semibold text-gray-800 mb-2">Services disponibles:</h4>
                <div class="flex flex-wrap gap-2">
                    ${isUrgence ? `
                    <span class="bg-red-100 text-red-600 px-2 py-1 rounded text-sm">Urgences 24h/24</span>
                    <span class="bg-red-100 text-red-600 px-2 py-1 rounded text-sm">Traumatologie</span>
                    <span class="bg-red-100 text-red-600 px-2 py-1 rounded text-sm">Douleurs aiguës</span>
                    ` : `
                    <span class="bg-cemedis-blue/10 text-cemedis-blue px-2 py-1 rounded text-sm">Soins généraux</span>
                    <span class="bg-cemedis-blue/10 text-cemedis-blue px-2 py-1 rounded text-sm">Consultations</span>
                    <span class="bg-cemedis-blue/10 text-cemedis-blue px-2 py-1 rounded text-sm">Spécialités</span>
                    `}
                </div>
            </div>
            
            <div class="flex gap-2">
                ${centre.telephone ? `
                <a href="tel:${centre.telephone.replace(/\s/g, '')}" class="flex-1 ${buttonColor} text-white px-4 py-2 rounded-lg text-center font-medium transition-colors">
                    ${isUrgence ? 'Urgences' : 'Appeler'}
                </a>
                ` : `
                <button class="flex-1 ${buttonColor} text-white px-4 py-2 rounded-lg text-center font-medium transition-colors opacity-50 cursor-not-allowed">
                    ${isUrgence ? 'Urgences' : 'Appeler'}
                </button>
                `}
                <button onclick="focusOnCentre('${centre.id}')" class="px-4 py-2 border ${borderColor} ${isUrgence ? 'text-red-600 hover:bg-red-50' : 'text-cemedis-blue hover:bg-cemedis-blue/10'} rounded-lg transition-colors" title="Voir sur la carte">
                    <i class="fas fa-map"></i>
                </button>
            </div>
        </div>
    `;
    
    return card;
}

// Fonction pour ouvrir la carte (Google Maps en nouvelle fenêtre)
function openMap(lat, lng) {
    if (lat && lng) {
        window.open(`https://www.google.com/maps?q=${lat},${lng}`, '_blank');
    } else {
        alert('Coordonnées GPS non disponibles');
    }
}

// La fonction focusOnCentre est définie dans map.js

// Fonction pour mettre à jour le filtre d'arrondissement
function updateArrondissementFilter() {
    const arrondissementFilter = document.getElementById('arrondissement-filter');
    if (!arrondissementFilter) return;
    
    // Récupérer tous les arrondissements uniques
    const arrondissements = [...new Set(allCentres
        .filter(c => c.code_postal && c.code_postal.startsWith('750'))
        .map(c => c.code_postal)
        .sort())];
    
    // Ajouter les options
    arrondissements.forEach(cp => {
        const arrNum = cp.substring(3);
        const option = document.createElement('option');
        option.value = cp;
        option.textContent = `${arrNum}ème arrondissement`;
        arrondissementFilter.appendChild(option);
    });
}

// Fonction de filtrage
function filterEstablishments() {
    const citySearch = document.getElementById('city-search');
    const arrondissementFilter = document.getElementById('arrondissement-filter');
    const serviceFilter = document.getElementById('service-filter');
    
    const filters = {
        ville: citySearch?.value || '',
        arrondissement: arrondissementFilter?.value || '',
        search: citySearch?.value || ''
    };
    
    const filtered = centresService.filterCentres(filters);
    displayCentres(filtered);
}

// Fonction pour charger plus de centres
function loadMoreCentres() {
    const loadMoreButton = document.getElementById('load-more');
    const centresCount = document.getElementById('centres-count');
    
    currentPage++;
    const startIndex = (currentPage - 1) * centresPerPage;
    const endIndex = startIndex + centresPerPage;
    const nextCentres = displayedCentres.slice(startIndex, endIndex);
    
    if (nextCentres.length > 0) {
        renderCentres(nextCentres);
        
        if (centresCount) {
            const displayed = Math.min(endIndex, displayedCentres.length);
            centresCount.textContent = `Affichage de ${displayed} sur ${displayedCentres.length} établissements`;
        }
        
        // Masquer le bouton si on a tout affiché
        if (endIndex >= displayedCentres.length) {
            if (loadMoreButton) {
                loadMoreButton.textContent = 'Tous les établissements sont affichés';
                loadMoreButton.disabled = true;
                loadMoreButton.classList.add('bg-gray-400', 'cursor-not-allowed');
                loadMoreButton.classList.remove('bg-cemedis-blue', 'hover:bg-cemedis-light-blue');
            }
        }
    }
}

// Initialisation au chargement de la page
document.addEventListener('DOMContentLoaded', function() {
    // Charger les centres depuis Supabase
    loadCentres();
    
    // Event listeners pour les filtres
    const citySearch = document.getElementById('city-search');
    const arrondissementFilter = document.getElementById('arrondissement-filter');
    const serviceFilter = document.getElementById('service-filter');
    
    if (citySearch) {
        citySearch.addEventListener('input', filterEstablishments);
    }
    
    if (arrondissementFilter) {
        arrondissementFilter.addEventListener('change', filterEstablishments);
    }
    
    if (serviceFilter) {
        serviceFilter.addEventListener('change', filterEstablishments);
    }
    
    // Bouton "Voir plus"
    const loadMoreButton = document.getElementById('load-more');
    if (loadMoreButton) {
        loadMoreButton.addEventListener('click', loadMoreCentres);
    }
    
    // Mettre à jour la carte quand les filtres changent
    if (typeof filterMapMarkers === 'function') {
        // Réécouter les événements de filtrage pour mettre à jour la carte
        const originalFilter = filterEstablishments;
        window.filterEstablishments = function() {
            originalFilter();
            if (allCentres.length > 0) {
                const citySearch = document.getElementById('city-search');
                const arrondissementFilter = document.getElementById('arrondissement-filter');
                
                const filters = {
                    ville: citySearch?.value || '',
                    arrondissement: arrondissementFilter?.value || ''
                };
                
                const filtered = centresService.filterCentres(filters);
                if (typeof filterMapMarkers === 'function') {
                    filterMapMarkers(filtered);
                }
            }
        };
    }
});