// Configuration Supabase - FICHIER D'EXEMPLE
// Copiez ce fichier en supabase-config.js et remplissez vos vraies clés

const SUPABASE_CONFIG = {
    // Remplacez par votre URL Supabase (ex: https://abcdefghijklmnop.supabase.co)
    url: 'https://your-project.supabase.co',
    
    // Remplacez par votre clé anonyme publique (anon key)
    anonKey: 'your-anon-key-here'
};

// Initialisation du client Supabase
let supabaseClient = null;

// Fonction pour initialiser Supabase
function initSupabase() {
    if (typeof supabase !== 'undefined') {
        supabaseClient = supabase.createClient(SUPABASE_CONFIG.url, SUPABASE_CONFIG.anonKey);
        return supabaseClient;
    } else {
        console.error('Supabase JS library not loaded. Please include: https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2');
        return null;
    }
}

// Initialiser au chargement si Supabase est disponible
if (typeof supabase !== 'undefined') {
    supabaseClient = initSupabase();
}
