// Carte interactive avec Leaflet pour afficher les centres CEMEDIS

let map = null;
let markers = [];
let markersGroup = null;

// Initialiser la carte
function initMap() {
    const mapContainer = document.getElementById('map');
    const mapLoading = document.getElementById('map-loading');
    
    if (!mapContainer) return;
    
    // Centre de la carte sur Paris
    map = L.map('map').setView([48.8566, 2.3522], 11);
    
    // Ajouter la couche de tuiles OpenStreetMap
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
        maxZoom: 19
    }).addTo(map);
    
    // Créer un groupe de marqueurs pour pouvoir les gérer ensemble
    markersGroup = L.layerGroup().addTo(map);
    
    // Cacher le loading et afficher la carte
    if (mapLoading) mapLoading.classList.add('hidden');
    mapContainer.classList.remove('hidden');
}

// Ajouter un marqueur pour un centre
function addCentreMarker(centre) {
    if (!map || !centre.latitude || !centre.longitude) return null;
    
    const isUrgence = centresService.isUrgenceCentre(centre);
    const adresseComplete = centresService.formatAdresse(centre);
    const arrondissement = centresService.getArrondissement(centre.code_postal);
    const horaires = centresService.formatHoraires(centre.horaires_ouverture);
    
    // Choisir l'icône selon le type de centre
    const iconColor = isUrgence ? 'red' : '#004B63';
    const iconHtml = `
        <div style="
            background-color: ${iconColor};
            width: 30px;
            height: 30px;
            border-radius: 50% 50% 50% 0;
            transform: rotate(-45deg);
            border: 3px solid white;
            box-shadow: 0 2px 4px rgba(0,0,0,0.3);
        ">
            <div style="
                transform: rotate(45deg);
                color: white;
                font-size: 18px;
                line-height: 24px;
                text-align: center;
                font-weight: bold;
            ">${isUrgence ? '!' : 'D'}</div>
        </div>
    `;
    
    const customIcon = L.divIcon({
        html: iconHtml,
        className: 'custom-marker',
        iconSize: [30, 30],
        iconAnchor: [15, 30],
        popupAnchor: [0, -30]
    });
    
    // Créer le contenu du popup
    const popupContent = `
        <div style="min-width: 250px;">
            <h3 style="font-weight: bold; font-size: 16px; margin-bottom: 8px; color: ${iconColor};">
                ${centre.nom || 'Centre CEMEDIS'}
            </h3>
            ${arrondissement ? `<p style="color: #666; font-size: 12px; margin-bottom: 8px;">${arrondissement}</p>` : ''}
            <div style="margin-bottom: 8px;">
                <i class="fas fa-map-marker-alt" style="color: ${iconColor}; width: 16px;"></i>
                <span style="font-size: 13px;">${adresseComplete}</span>
            </div>
            ${centre.telephone ? `
            <div style="margin-bottom: 8px;">
                <i class="fas fa-phone" style="color: ${iconColor}; width: 16px;"></i>
                <a href="tel:${centre.telephone.replace(/\s/g, '')}" style="font-size: 13px; color: ${iconColor}; text-decoration: none;">
                    ${centre.telephone}
                </a>
            </div>
            ` : ''}
            <div style="margin-bottom: 8px;">
                <i class="fas fa-clock" style="color: ${iconColor}; width: 16px;"></i>
                <span style="font-size: 13px;">${horaires}</span>
            </div>
            <div style="margin-top: 12px; display: flex; gap: 8px;">
                ${centre.telephone ? `
                <a href="tel:${centre.telephone.replace(/\s/g, '')}" 
                   style="flex: 1; background-color: ${iconColor}; color: white; padding: 8px 12px; border-radius: 4px; text-align: center; text-decoration: none; font-size: 13px; font-weight: 500;">
                    ${isUrgence ? 'Urgences' : 'Appeler'}
                </a>
                ` : ''}
                <button onclick="focusOnCentre('${centre.id}')" 
                        style="background-color: white; color: ${iconColor}; padding: 8px 12px; border: 1px solid ${iconColor}; border-radius: 4px; cursor: pointer; font-size: 13px;">
                    Voir détails
                </button>
            </div>
        </div>
    `;
    
    // Créer le marqueur
    const marker = L.marker([centre.latitude, centre.longitude], { icon: customIcon })
        .addTo(markersGroup)
        .bindPopup(popupContent);
    
    // Stocker les informations du centre dans le marqueur
    marker.centreId = centre.id;
    marker.centre = centre;
    
    markers.push(marker);
    
    return marker;
}

// Ajouter tous les centres sur la carte
function addAllCentresToMap(centres) {
    if (!map || !centres || centres.length === 0) return;
    
    // Nettoyer les marqueurs existants
    clearMapMarkers();
    
    // Ajouter chaque centre
    const bounds = [];
    centres.forEach(centre => {
        if (centre.latitude && centre.longitude) {
            const marker = addCentreMarker(centre);
            if (marker) {
                bounds.push([centre.latitude, centre.longitude]);
            }
        }
    });
    
    // Ajuster la vue pour afficher tous les marqueurs
    if (bounds.length > 0) {
        if (bounds.length === 1) {
            map.setView(bounds[0], 13);
        } else {
            map.fitBounds(bounds, { padding: [50, 50], maxZoom: 13 });
        }
    }
}

// Nettoyer tous les marqueurs
function clearMapMarkers() {
    if (markersGroup) {
        markersGroup.clearLayers();
    }
    markers = [];
}

// Filtrer les marqueurs sur la carte
function filterMapMarkers(filteredCentres) {
    clearMapMarkers();
    addAllCentresToMap(filteredCentres);
}

// Focus sur un centre spécifique (fonction globale)
window.focusOnCentre = function(centreId) {
    const marker = markers.find(m => m.centreId === centreId);
    if (marker && map) {
        map.setView([marker.centre.latitude, marker.centre.longitude], 15);
        marker.openPopup();
        
        // Scroll vers la carte
        setTimeout(() => {
            const mapElement = document.getElementById('map');
            if (mapElement) {
                mapElement.scrollIntoView({ behavior: 'smooth', block: 'center' });
            }
        }, 300);
    }
}

// Initialiser la carte au chargement
document.addEventListener('DOMContentLoaded', function() {
    // Attendre que les centres soient chargés
    const checkCentresLoaded = setInterval(() => {
        if (centresService && centresService.loaded) {
            clearInterval(checkCentresLoaded);
            
            // Initialiser la carte
            initMap();
            
            // Ajouter les centres sur la carte
            const centres = centresService.getCentres();
            addAllCentresToMap(centres);
        }
    }, 500);
    
    // Timeout de sécurité
    setTimeout(() => {
        clearInterval(checkCentresLoaded);
        if (!map) {
            initMap();
        }
    }, 10000);
});
