// Service pour gérer les centres dentaires depuis Supabase

class CentresService {
    constructor() {
        this.centres = [];
        this.centresUrgences = [];
        this.loaded = false;
    }

    // Initialiser Supabase si nécessaire
    initSupabase() {
        if (!supabaseClient && typeof supabase !== 'undefined') {
            supabaseClient = supabase.createClient(SUPABASE_CONFIG.url, SUPABASE_CONFIG.anonKey);
        }
        return supabaseClient;
    }

    // Charger tous les centres depuis Supabase
    async loadCentres() {
        try {
            const client = this.initSupabase();
            if (!client) {
                console.error('Supabase client not initialized');
                return [];
            }

            const { data, error } = await client
                .from('centres')
                .select('*')
                .eq('statut', 'actif')
                .order('ville', { ascending: true })
                .order('nom', { ascending: true });

            if (error) {
                console.error('Error loading centres:', error);
                return [];
            }

            this.centres = data || [];
            this.loaded = true;
            
            // Identifier les centres d'urgences (vous pouvez ajuster cette logique)
            this.centresUrgences = this.centres.filter(centre => 
                centre.nom.toLowerCase().includes('urgence') || 
                centre.nom.toLowerCase().includes('urgences')
            );

            return this.centres;
        } catch (error) {
            console.error('Exception loading centres:', error);
            return [];
        }
    }

    // Obtenir tous les centres
    getCentres() {
        return this.centres;
    }

    // Obtenir un centre par ID
    getCentreById(id) {
        return this.centres.find(c => c.id === id);
    }

    // Obtenir les centres d'urgences
    getCentresUrgences() {
        return this.centresUrgences.length > 0 
            ? this.centresUrgences 
            : this.centres.slice(0, 3); // Fallback: premiers 3 centres
    }

    // Filtrer les centres
    filterCentres(filters) {
        let filtered = [...this.centres];

        // Filtre par ville
        if (filters.ville) {
            const villeLower = filters.ville.toLowerCase();
            filtered = filtered.filter(c => 
                c.ville?.toLowerCase().includes(villeLower) ||
                c.adresse?.toLowerCase().includes(villeLower)
            );
        }

        // Filtre par arrondissement (code postal)
        if (filters.arrondissement) {
            filtered = filtered.filter(c => 
                c.code_postal === filters.arrondissement
            );
        }

        // Filtre par recherche textuelle
        if (filters.search) {
            const searchLower = filters.search.toLowerCase();
            filtered = filtered.filter(c => 
                c.nom?.toLowerCase().includes(searchLower) ||
                c.ville?.toLowerCase().includes(searchLower) ||
                c.adresse?.toLowerCase().includes(searchLower)
            );
        }

        return filtered;
    }

    // Formater les horaires depuis JSONB
    formatHoraires(horairesJson) {
        if (!horairesJson) {
            return 'Lun-Ven: 8h-19h, Sam: 9h-17h';
        }

        try {
            if (typeof horairesJson === 'string') {
                horairesJson = JSON.parse(horairesJson);
            }

            // Format personnalisé selon votre structure JSON
            if (horairesJson.lundi) {
                return `Lun-Ven: ${horairesJson.lundi || '8h-19h'}, Sam: ${horairesJson.samedi || '9h-17h'}`;
            }

            return JSON.stringify(horairesJson);
        } catch (e) {
            return 'Lun-Ven: 8h-19h, Sam: 9h-17h';
        }
    }

    // Formater l'adresse complète
    formatAdresse(centre) {
        const parts = [centre.adresse];
        if (centre.code_postal) parts.push(centre.code_postal);
        if (centre.ville) parts.push(centre.ville);
        return parts.join(', ');
    }

    // Obtenir l'arrondissement depuis le code postal
    getArrondissement(codePostal) {
        if (!codePostal) return '';
        if (codePostal.startsWith('750')) {
            return codePostal.substring(3) + 'ème arrondissement';
        }
        return '';
    }

    // Vérifier si un centre est un centre d'urgences
    isUrgenceCentre(centre) {
        return centre.nom.toLowerCase().includes('urgence') || 
               centre.nom.toLowerCase().includes('urgences') ||
               this.centresUrgences.some(c => c.id === centre.id);
    }
}

// Instance globale du service
const centresService = new CentresService();
